@component('mail::message')
<p>Dear Sir/Madam,</p>


<p>{{$details['Type']}} MRF submitted by you has been {{$details['Status']}} by the Admin. To see details, login to your account and see the details under the MRF page.</p>
<br>
<small><b></i>*Please do not reply to this email- This is an automated message and responses cannot be received by our system.</i></b></small>
<br>



Thanks,<br>
VNR Recruitment
@endcomponent
