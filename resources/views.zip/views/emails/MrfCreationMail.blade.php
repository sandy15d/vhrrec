@component('mail::message')
<p>Dear Sir/Madam,</p>

<p>New MRF has been created by {{$details['Employee']}}</p>
<p>To act login to your account and see the details under the MRF page.

<small>*Please do not reply to this email- This is an automated message and responses cannot be received by our system.</small>




Thanks,<br>
VNR Recruitment
@endcomponent
